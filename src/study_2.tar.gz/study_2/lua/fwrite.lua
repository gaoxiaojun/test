function fwrite(fmt, ...)
	return io.write(string.format(fmt, ...))
end
