for i = -10, 10 do
	print(i, i % 3)
end
