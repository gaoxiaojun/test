print(arg[0])
