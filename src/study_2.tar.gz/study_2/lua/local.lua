x = 10
local i = 1
while i <= x do
	local x = i * 2
	print(x)
	i = i + 1
end
