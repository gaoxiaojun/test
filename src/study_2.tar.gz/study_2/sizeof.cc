#include <iostream>
using namespace std;

void f()
{
}

int main()
{
	cout << "sizeof f()" << sizeof f() << endl;
//	cout << "sizeof f" << sizeof f << endl;
	return 0;
}
