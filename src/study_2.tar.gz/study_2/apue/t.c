#include <stdio.h>

int main()
{
    printf("Hello, world!\n");
    fprintf(stderr, "%s", "Hello, error!\n");
    return 0;
}
