#include "apue.h"

int mydup(int oldfd, int newfd)
{
    int fd = open(
}
