echo "The value of the ee variable is: $ee"
